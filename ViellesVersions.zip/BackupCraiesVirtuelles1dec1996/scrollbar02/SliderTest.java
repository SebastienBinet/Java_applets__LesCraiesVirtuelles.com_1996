/* text areas */

import java.awt.*;

public class SliderTest extends java.applet.Applet {
  Label l;

  public void init() {
    this.setLayout(new GridLayout(3,3));
    l = new Label("0");
    add(l);
    add(new Scrollbar(Scrollbar.HORIZONTAL,0,0,1,1000));
  }

  public boolean handleEvent(Event evt) {
    if (evt.target instanceof Scrollbar) {
      int v = ((Scrollbar)evt.target).getValue();
      l.setText(String.valueOf(v));
    }
    return true;
  }

}
